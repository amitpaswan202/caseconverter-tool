// DOM Elements
const inputText = document.getElementById('inputText');
const outputText = document.getElementById('outputText');
const copyBtn = document.getElementById('copyBtn');
const clearBtn = document.getElementById('clearBtn');
const swapBtn = document.getElementById('swapBtn');
const downloadBtn = document.getElementById('downloadBtn');
const themeToggle = document.getElementById('themeToggle');
const themeIcon = document.getElementById('themeIcon');
const themeText = document.getElementById('themeText');

// Stats elements
const charCount = document.getElementById('charCount');
const wordCount = document.getElementById('wordCount');
const lineCount = document.getElementById('lineCount');
const outputCharCount = document.getElementById('outputCharCount');
const outputWordCount = document.getElementById('outputWordCount');

// Toast notification
const notification = document.getElementById('notification');
const toastMessage = document.getElementById('toastMessage');

// Initialize theme from localStorage
let isDarkMode = localStorage.getItem('darkMode') === 'true';
if (isDarkMode) {
    document.body.classList.add('dark-mode');
    themeIcon.className = 'fas fa-sun';
    themeText.textContent = 'Light Mode';
}

// Theme toggle functionality
themeToggle.addEventListener('click', () => {
    isDarkMode = !isDarkMode;
    document.body.classList.toggle('dark-mode');
    
    if (isDarkMode) {
        themeIcon.className = 'fas fa-sun';
        themeText.textContent = 'Light Mode';
    } else {
        themeIcon.className = 'fas fa-moon';
        themeText.textContent = 'Dark Mode';
    }
    
    localStorage.setItem('darkMode', isDarkMode);
});

// Text statistics update
function updateStats() {
    const input = inputText.value;
    const output = outputText.value;
    
    // Input stats
    charCount.textContent = input.length;
    wordCount.textContent = input.trim() ? input.trim().split(/\s+/).length : 0;
    lineCount.textContent = input.split('\n').length;
    
    // Output stats
    outputCharCount.textContent = output.length;
    outputWordCount.textContent = output.trim() ? output.trim().split(/\s+/).length : 0;
}

// Show notification
function showNotification(message, type = 'success') {
    toastMessage.textContent = message;
    const toast = new bootstrap.Toast(notification);
    toast.show();
}

// Text conversion functions
const textConverters = {
    // Case conversion functions
    uppercase: (text) => text.toUpperCase(),
    
    lowercase: (text) => text.toLowerCase(),
    
    titlecase: (text) => text.replace(/\w\S*/g, (txt) => 
        txt.charAt(0).toUpperCase() + txt.substr(1).toLowerCase()
    ),
    
    sentencecase: (text) => text.toLowerCase().replace(/(^\s*\w|[.!?]\s*\w)/g, (c) => 
        c.toUpperCase()
    ),
    
    capitalizedcase: (text) => text.split(' ').map(word => 
        word.charAt(0).toUpperCase() + word.slice(1).toLowerCase()
    ).join(' '),
    
    alternatingcase: (text) => text.split('').map((char, index) => 
        index % 2 === 0 ? char.toLowerCase() : char.toUpperCase()
    ).join(''),
    
    inversecase: (text) => text.split('').map(char => 
        char === char.toUpperCase() ? char.toLowerCase() : char.toUpperCase()
    ).join(''),
    
    camelcase: (text) => text.replace(/(?:^\w|[A-Z]|\b\w)/g, (word, index) => 
        index === 0 ? word.toLowerCase() : word.toUpperCase()
    ).replace(/\s+/g, ''),
    
    pascalcase: (text) => text.replace(/(?:^\w|[A-Z]|\b\w)/g, (word) => 
        word.toUpperCase()
    ).replace(/\s+/g, ''),
    
    snakecase: (text) => text.toLowerCase().replace(/\s+/g, '_').replace(/[^\w]/g, ''),
    
    kebabcase: (text) => text.toLowerCase().replace(/\s+/g, '-').replace(/[^\w-]/g, ''),
    
    dotcase: (text) => text.toLowerCase().replace(/\s+/g, '.').replace(/[^\w.]/g, ''),
    
    underscorecase: (text) => text.replace(/\s+/g, '_'),
    
    dashcase: (text) => text.replace(/\s+/g, '-'),
    
    // Remove functions
    removespaces: (text) => text.replace(/\s/g, ''),
    
    removepunctuation: (text) => text.replace(/[^\w\s]/g, ''),
    
    removenumbers: (text) => text.replace(/\d/g, ''),
    
    removesymbols: (text) => text.replace(/[^\w\s]/g, ''),
    
    removelinebreaks: (text) => text.replace(/\n/g, ' '),
    
    removeextraspaces: (text) => text.replace(/\s+/g, ' ').trim(),
    
    // Encoding functions
    texttoascii: (text) => text.split('').map(char => char.charCodeAt(0)).join(' '),
    
    texttobinary: (text) => text.split('').map(char => 
        char.charCodeAt(0).toString(2).padStart(8, '0')
    ).join(' '),
    
    texttomorse: (text) => {
        const morseCode = {
            'A': '.-', 'B': '-...', 'C': '-.-.', 'D': '-..', 'E': '.', 'F': '..-.',
            'G': '--.', 'H': '....', 'I': '..', 'J': '.---', 'K': '-.-', 'L': '.-..',
            'M': '--', 'N': '-.', 'O': '---', 'P': '.--.', 'Q': '--.-', 'R': '.-.',
            'S': '...', 'T': '-', 'U': '..-', 'V': '...-', 'W': '.--', 'X': '-..-',
            'Y': '-.--', 'Z': '--..', '0': '-----', '1': '.----', '2': '..---',
            '3': '...--', '4': '....-', '5': '.....', '6': '-....', '7': '--...',
            '8': '---..', '9': '----.', ' ': '/'
        };
        return text.toUpperCase().split('').map(char => morseCode[char] || char).join(' ');
    },
    
    texttobase64: (text) => btoa(unescape(encodeURIComponent(text))),
    
    texttohex: (text) => text.split('').map(char => 
        char.charCodeAt(0).toString(16).padStart(2, '0')
    ).join(' '),
    
    // Decode functions
    base64totext: (text) => {
        try {
            return decodeURIComponent(escape(atob(text.trim())));
        } catch (e) {
            return 'Invalid Base64 input';
        }
    },
    
    hextotext: (text) => {
        try {
            return text.split(' ').map(hex => 
                String.fromCharCode(parseInt(hex, 16))
            ).join('');
        } catch (e) {
            return 'Invalid Hex input';
        }
    },
    
    binarytotext: (text) => {
        try {
            return text.split(' ').map(binary => 
                String.fromCharCode(parseInt(binary, 2))
            ).join('');
        } catch (e) {
            return 'Invalid Binary input';
        }
    },
    
    // Other utility functions
    reversetext: (text) => text.split('').reverse().join(''),
    
    reversewords: (text) => text.split(' ').reverse().join(' '),
    
    shufflewords: (text) => {
        const words = text.split(' ');
        for (let i = words.length - 1; i > 0; i--) {
            const j = Math.floor(Math.random() * (i + 1));
            [words[i], words[j]] = [words[j], words[i]];
        }
        return words.join(' ');
    },
    
    sortlines: (text) => text.split('\n').sort().join('\n'),
    
    removelines: (text) => [...new Set(text.split('\n'))].join('\n'),
    
    randomize: (text) => {
        const lines = text.split('\n');
        for (let i = lines.length - 1; i > 0; i--) {
            const j = Math.floor(Math.random() * (i + 1));
            [lines[i], lines[j]] = [lines[j], lines[i]];
        }
        return lines.join('\n');
    }
};

// Tool button event handlers
document.addEventListener('click', (e) => {
    if (e.target.matches('button[data-action]')) {
        const action = e.target.getAttribute('data-action');
        const input = inputText.value;
        
        if (!input.trim()) {
            showNotification('Please enter some text first', 'warning');
            return;
        }
        
        // Add pressed animation
        e.target.classList.add('pressed');
        setTimeout(() => e.target.classList.remove('pressed'), 200);
        
        if (textConverters[action]) {
            try {
                const result = textConverters[action](input);
                outputText.value = result;
                updateStats();
                showNotification(`Text converted using ${action}`, 'success');
            } catch (error) {
                showNotification('Error converting text: ' + error.message, 'error');
            }
        }
    }
});

// Copy to clipboard
copyBtn.addEventListener('click', async () => {
    if (!outputText.value.trim()) {
        showNotification('No text to copy', 'warning');
        return;
    }
    
    try {
        await navigator.clipboard.writeText(outputText.value);
        showNotification('Text copied to clipboard!', 'success');
        
        // Visual feedback for the button
        const originalHTML = copyBtn.innerHTML;
        copyBtn.innerHTML = '<i class="fas fa-check me-2"></i>Copied!';
        
        setTimeout(() => {
            copyBtn.innerHTML = originalHTML;
        }, 1500);
    } catch (err) {
        // Fallback for older browsers
        outputText.select();
        document.execCommand('copy');
        showNotification('Text copied to clipboard!', 'success');
    }
});

// Clear all text
clearBtn.addEventListener('click', () => {
    inputText.value = '';
    outputText.value = '';
    updateStats();
    showNotification('All text cleared', 'info');
});

// Swap input and output
swapBtn.addEventListener('click', () => {
    if (!outputText.value.trim()) {
        showNotification('No output text to swap', 'warning');
        return;
    }
    
    const temp = inputText.value;
    inputText.value = outputText.value;
    outputText.value = temp;
    updateStats();
    showNotification('Input and output swapped', 'info');
});

// Download as text file
downloadBtn.addEventListener('click', () => {
    const text = outputText.value || inputText.value;
    if (!text.trim()) {
        showNotification('No text to download', 'warning');
        return;
    }
    
    const blob = new Blob([text], { type: 'text/plain' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = 'converted-text.txt';
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
    showNotification('Text file downloaded', 'success');
});

// Update stats on input
inputText.addEventListener('input', updateStats);
outputText.addEventListener('input', updateStats);

// Initialize stats
updateStats();

// Auto-save input text to localStorage
inputText.addEventListener('input', () => {
    localStorage.setItem('savedText', inputText.value);
});

// Restore saved text on page load
window.addEventListener('load', () => {
    const savedText = localStorage.getItem('savedText');
    if (savedText) {
        inputText.value = savedText;
        updateStats();
    }
});

// Keyboard shortcuts
document.addEventListener('keydown', (e) => {
    // Ctrl+Enter to copy
    if (e.ctrlKey && e.key === 'Enter') {
        e.preventDefault();
        copyBtn.click();
    }
    
    // Ctrl+Shift+C to clear
    if (e.ctrlKey && e.shiftKey && e.key === 'C') {
        e.preventDefault();
        clearBtn.click();
    }
    
    // Ctrl+Shift+S to swap
    if (e.ctrlKey && e.shiftKey && e.key === 'S') {
        e.preventDefault();
        swapBtn.click();
    }
    
    // Ctrl+D to download
    if (e.ctrlKey && e.key === 'd') {
        e.preventDefault();
        downloadBtn.click();
    }
});

console.log('Text Case Converter loaded successfully!');
